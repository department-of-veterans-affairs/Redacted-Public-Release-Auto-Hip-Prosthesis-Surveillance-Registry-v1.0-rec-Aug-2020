# auto-hip-prosthesis-surveillance-registry
Automated Hip Prosthesis Surveillance Registry Project

This project developed an automated level 1 registry of total hip arthroplasty implant components from passively collected data in the Department of Veterans Affairs (VA) Corporate Data Warehouse.  This work was the product of a VA Health Services Research and Development pilot research grant (1 I21 HX002413-01A1 (PPO 17-026)).  The code was written by John Radin (john.radin@va.gov).  Additional investigators on this project were Nicholas Giori (nicholas.giori@va.gov) and Alex Sox-Harris (alexander.harris2@va.gov).  Please let Dr. Giori or Dr. Harris know if you will be using this code in future research.  We are interested in future collaborations.
